package executionEngine;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.xml.DOMConfigurator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import config.ActionKeywords;
import config.Constants;
import utility.Common;
import utility.DateTimeFunctions;
import utility.ExcelUtils;
import utility.Log;

public class EngineGeneric {

    public static Properties OR;
    public static String sActionKeyword;
    public static String sPageObject;
    public static int iTestStep;
    public static int iTestLastStep;
    public static String sTestCaseID;
    public static String sOriginalTestCaseID;
    public static String sRunMode;
    public static String sData;
    public static String sPrint;
    public static boolean bResult;
    public static int columnOfParameter;
    public static String failStep;
    public static boolean failBrowser;
    public static String inicialTime;
    public static String finalTime;
    public static int cdTestCase;

    public static String sUrl;
    public static String sTimeLoadUrl;
    public static String sTimeDelayActions;
    public static String sRepeatError;
    public static String sCloseBrowserError;
    public static String sStopTestsError;
    public static String sPathTestData;
    public static String sPathOR;
    public static String sPathDrivers;
    public static String sPathLog;
    public static String sUserB;
    public static String sPasswordB;

    public static void initialize_Test() throws Exception {
        read_Config();

        String Path_OR = sPathOR;
        FileInputStream fs2 = new FileInputStream(Path_OR);
        OR = new Properties(System.getProperties());
        OR.load(new InputStreamReader(fs2, Charset.forName("UTF-8")));

        ExcelUtils.setExcelFile(sPathTestData);
        System.setProperty("logFilePath", sPathLog);
        DOMConfigurator.configure("log4j.xml");
    }

    public static void execute_TestCase(ActionKeywords actionKeywords, Method[] method2) throws Exception {
        ExcelUtils.clearCellResults(Constants.Col_Time, Constants.Sheet_TestCases);
        ExcelUtils.clearCellResults(Constants.Col_Result, Constants.Sheet_TestCases);
        ExcelUtils.clearCellResults(Constants.Col_StepFail, Constants.Sheet_TestCases);
        int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
        int controllerFail = 0;
        for (int iTestcase = 1; iTestcase < iTotalTestCases; iTestcase++) {
            cdTestCase = iTestcase;
            columnOfParameter = 0;
            bResult = true;
            sTestCaseID = ExcelUtils.getCellData(iTestcase, Constants.Col_TestCaseID, Constants.Sheet_TestCases);
            sRunMode = ExcelUtils.getCellData(iTestcase, Constants.Col_RunMode, Constants.Sheet_TestCases);
            sOriginalTestCaseID = sTestCaseID;
            if (Character.isLetter(sTestCaseID.charAt(sTestCaseID.length() - 1))) {
                sTestCaseID = sTestCaseID.substring(0, sTestCaseID.length() - 2);
                switch (sOriginalTestCaseID.substring(sOriginalTestCaseID.length() - 1).toUpperCase()) {
                case "I":
                    columnOfParameter = 1;
                    break;
                case "J":
                    columnOfParameter = 2;
                    break;
                case "K":
                    columnOfParameter = 3;
                    break;
                case "L":
                    columnOfParameter = 4;
                    break;
                case "M":
                    columnOfParameter = 5;
                    break;
                case "N":
                    columnOfParameter = 6;
                    break;
                case "O":
                    columnOfParameter = 7;
                    break;
                case "P":
                    columnOfParameter = 8;
                    break;
                case "Q":
                    columnOfParameter = 9;
                    break;
                default:
                    break;
                }
                if (!sOriginalTestCaseID.substring(sOriginalTestCaseID.length() - 2, sOriginalTestCaseID.length() - 1).equals("_")) {
                    sRunMode = "No";
                    bResult = false;
                    Log.startTestCase(sOriginalTestCaseID);
                    Log.error("O ID do caso de teste está incorreto! O ID deve terminar com um número (TC_01002) ou com '_' mais uma letra indicando "
                            + "a coluna com os dados de teste (TC_01002_K)");
                    Log.endTestCase(sTestCaseID);
                    ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,Constants.Sheet_TestCases);
                    ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail, Constants.Sheet_TestCases);
                    ExcelUtils.setCellData(DateTimeFunctions.getDifferenceBetweenTimes(inicialTime, finalTime), iTestcase, Constants.Col_Time,
                        Constants.Sheet_TestCases);
                }
            }

            if (sRunMode.equals("Sim")) {
                iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                iTestLastStep = ExcelUtils.getTestStepsCount(Constants.Sheet_TestSteps, sTestCaseID, iTestStep);
                Log.startTestCase(sOriginalTestCaseID);
                bResult = true;
                for (; iTestStep < iTestLastStep; iTestStep++) {
                    sActionKeyword = ExcelUtils.getCellData(iTestStep, Constants.Col_ActionKeyword,
                        Constants.Sheet_TestSteps).trim();
                    sPageObject = ExcelUtils.getPageObject(iTestStep, Constants.Col_PageObject,
                        Constants.Sheet_TestSteps);
                    sData = ExcelUtils.getCellData(iTestStep, Constants.Col_DataSet + columnOfParameter,
                        Constants.Sheet_TestSteps);
                    sPrint = ExcelUtils.getCellData(iTestStep, Constants.Col_Print, Constants.Sheet_TestSteps);

                    if (bResult == true){
                        execute_Actions(actionKeywords, method2);    
                    }

                    if (bResult == false) {
                        if (sStopTestsError.equals("S")) {
                            ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                Constants.Sheet_TestCases);
                            ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                Constants.Sheet_TestCases);
                            iTestcase = iTotalTestCases;
                        } else {
                            if (!sRepeatError.equals("S")) {
                                ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                    Constants.Sheet_TestCases);
                                ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                    Constants.Sheet_TestCases);
                            } else {
                                if (controllerFail < 3) {
                                    if (controllerFail == 2) {
                                        ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                            Constants.Sheet_TestCases);
                                        ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                            Constants.Sheet_TestCases);
                                        controllerFail = 0;
                                    } else {
                                        controllerFail++;
                                        iTestcase--;
                                    }
                                }
                            }
                        }
                        Log.endTestCase(sTestCaseID);
                        break;
                    }
                }

                if (bResult == true) {
                    controllerFail = 0;
                    Log.endTestCase(sTestCaseID);
                    ExcelUtils.setCellData(Constants.KEYWORD_PASS, iTestcase, Constants.Col_Result,Constants.Sheet_TestCases);
                    ExcelUtils.setCellData(DateTimeFunctions.getDifferenceBetweenTimes(inicialTime, finalTime), iTestcase, Constants.Col_Time,
                        Constants.Sheet_TestCases);
                }
            }
        }
    }

    private static void execute_Actions(ActionKeywords actionKeywords, Method[] method2) throws Exception {
        boolean existMethod = false; 
        for (int i = 0; i < method2.length; i++) {
            if (method2[i].getName().equalsIgnoreCase(sActionKeyword)) {
                method2[i].invoke(actionKeywords, sPageObject, sData, sPrint);
                existMethod = true;
                if (bResult == true) {
                    break;
                } else if (failBrowser == true) {
                    failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                    bResult = false;
                    break;
                } else {
                    failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                    if (sCloseBrowserError.equals("S")) {
                        ActionKeywords.closeBrowser("", "", "");
                    }
                    break;
                }
            }
        }
        if(existMethod == false){
            bResult = false;
            failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
            Log.error("O método (keyword) informado '" + sActionKeyword + "' não existe.");
            if (sCloseBrowserError.equals("S")) {
                ActionKeywords.closeBrowser("", "", "");
            }
        }
    }

    public static void read_Config() throws Exception {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(Constants.PathApplication + "/config.xml");
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("parameters");

        for (int temp = 0; temp < nList.getLength(); temp++) {
            Node nNode = nList.item(temp);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                sUrl = eElement.getElementsByTagName("url").item(0).getTextContent();
                sTimeLoadUrl = eElement.getElementsByTagName("timeloadurl").item(0).getTextContent();
                sTimeDelayActions = eElement.getElementsByTagName("timedelayactions").item(0).getTextContent();
                sRepeatError = eElement.getElementsByTagName("repeaterror").item(0).getTextContent();
                sCloseBrowserError = eElement.getElementsByTagName("closebrowsererror").item(0).getTextContent();
                sStopTestsError = eElement.getElementsByTagName("stoptestserror").item(0).getTextContent();
                sPathTestData = Common.convertPathWindowsFormat(
                    eElement.getElementsByTagName("pathtestdata").item(0).getTextContent()) + "/DataEngine.xlsx";
                sPathOR = Common.convertPathWindowsFormat(
                    eElement.getElementsByTagName("pathor").item(0).getTextContent()) + "/OR.txt";
                sPathDrivers = Common.convertPathWindowsFormat(
                    eElement.getElementsByTagName("pathdrivers").item(0).getTextContent()) + "/";
                sPathLog = Common
                    .convertPathWindowsFormat(eElement.getElementsByTagName("pathlog").item(0).getTextContent());
                sUserB = eElement.getElementsByTagName("userB").item(0).getTextContent();
                sPasswordB = eElement.getElementsByTagName("passwordB").item(0).getTextContent();
            }
        }
    }

    public static void end_Drivers() throws Exception {
        if (Constants.TypeBrowser == 1) {
            if (Common.getsProcessesRunning().contains("geckodriver")) {
                Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
            }
            if (Common.getsProcessesRunning().contains("firefox")) {
                Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
            }
        } else if (Constants.TypeBrowser == 2) {
            if (Common.getsProcessesRunning().contains("IEDriverServer")) {
                Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
            }
            if (Common.getsProcessesRunning().contains("iexplore")) {
                Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
            }
        } else if (Constants.TypeBrowser == 3) {
            if (Common.getsProcessesRunning().contains("chromedriver")) {
                Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
            }
        }
    }
}
