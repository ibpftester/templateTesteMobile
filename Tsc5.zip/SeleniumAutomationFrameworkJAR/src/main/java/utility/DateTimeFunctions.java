package utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeFunctions {

    public static String getTimeScreenShot() {
        return new SimpleDateFormat("HH.mm.ss.SSS").format(new Date().getTime());
    }

    public static String getCurrentDate() {
        return new SimpleDateFormat("yyyy.MM.dd").format(new Date().getTime());
    }

    public static String getCurrentDateBrFormat() {
        return new SimpleDateFormat("dd/MM/yyyy").format(new Date().getTime());
    }

    public static Date convertStringToDate(String date) {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date newDate = null;
        try {
            newDate = formatter.parse(date);
        } catch (ParseException e) {
            Log.error("Falha ao converter string para data --- " + e);
        }
        return newDate;
    }
    
    public static String getDifferenceBetweenTimes(String inicialTime, String finalTime) {
        
        SimpleDateFormat format = new SimpleDateFormat("HH.mm.ss");
        
        
        Date d1 = null;
        Date d2 = null;
        
        String teste = "";

        try {
                d1 = format.parse(inicialTime);
                d2 = format.parse(finalTime);

                long diff = d2.getTime() - d1.getTime();

                String diffSeconds = String.format("%02d", diff / 1000 % 60);
                String diffMinutes = String.format("%02d", diff / (60 * 1000) % 60);
                String diffHours = String.format("%02d", diff / (60 * 60 * 1000) % 24);
                
                teste = diffHours + ":" + diffMinutes + ":" + diffSeconds;

        } catch (ParseException e) {
            Log.error("Falha ao converter string para data/time --- " + e);
        }
        return teste;
    }
}
