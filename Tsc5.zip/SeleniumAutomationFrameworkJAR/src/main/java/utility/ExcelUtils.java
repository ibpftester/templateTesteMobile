package utility;

import static executionEngine.EngineGeneric.OR;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import config.Constants;
import executionEngine.EngineGeneric;

public class ExcelUtils {

    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFRow Row;

    public static void setExcelFile(String path) throws Exception {
        try {
            FileInputStream excelFile = new FileInputStream(path);
            ExcelWBook = new XSSFWorkbook(excelFile);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setExcelFile | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    public static String getCellData(int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            Row = ExcelWSheet.getRow(rowNum);
            FormulaEvaluator evaluator = ExcelWBook.getCreationHelper().createFormulaEvaluator();
            String cellData = "";
            if (Row != null) {
                if (Row.getCell(colNum) != null) {
                    if (Row.getCell(colNum).getCellType() == 1) {
                        cellData = Row.getCell(colNum).getStringCellValue();
                    } else if (Row.getCell(colNum).getCellType() == 0) {
                        XSSFCell xssfCell = Row.getCell(colNum);
                        xssfCell.setCellType(1);
                        cellData = xssfCell.getStringCellValue();
                    } else if (Row.getCell(colNum).getCellType() == 2) {
                        switch (evaluator.evaluateFormulaCell(Row.getCell(colNum))) {
                        case Cell.CELL_TYPE_STRING:
                            cellData = Row.getCell(colNum).getStringCellValue();
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            cellData = String.valueOf(Row.getCell(colNum).getNumericCellValue());
                            break;
                        case Cell.CELL_TYPE_BOOLEAN:
                            cellData = String.valueOf(Row.getCell(colNum).getBooleanCellValue());
                            break;
                        case Cell.CELL_TYPE_BLANK:
                            cellData = "";
                            break;
                        default:
                            cellData = Row.getCell(colNum).getStringCellValue();
                        }
                    } else {
                        XSSFCell xssfCell = Row.getCell(colNum);
                        cellData = xssfCell.getStringCellValue();
                    }
                }
            }
            return cellData;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getCellData | Exception desc : " + e);
            EngineGeneric.bResult = false;
            return "";
        }
    }

    public static String getPageObject(int rowNum, int colNum, String sheetName) throws Exception {
        try {
            String element = getCellData(rowNum, colNum, sheetName);
            if(element.length() > 1){
                if(OR.getProperty(element).isEmpty()){
                    EngineGeneric.failStep = ExcelUtils.getCellData(EngineGeneric.iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                    Log.error("O elemento mapeado '" + element + "' não existe no arquivo OR.txt!");
                    EngineGeneric.bResult = false;
                    return "";
                }
                else{
                    return element;
                }                
            }
            return element;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getCellData | Exception desc : " + e);
            EngineGeneric.bResult = false;
            return "";
        }
    }

    public static int getRowCount(String sheetName) {
        int iNumber = 0;
        XSSFSheet sheet = null;
        try {
            sheet = ExcelWBook.getSheet(sheetName);
            iNumber = sheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowCount | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return getCellsWithValue(sheet, iNumber);
    }

    public static int getRowCountSteps(String sheetName) {
        int iNumber = 0;
        try {
            XSSFSheet sheet = ExcelWBook.getSheet(sheetName);
            iNumber = sheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowCountSteps | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return iNumber;
    }
    
    public static int getRowContains(String sTestCaseName, int colNum, String sheetName) throws Exception {
        int iRowNum = 1;
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            int rowCount = ExcelUtils.getRowCountSteps(sheetName);
            for (; iRowNum < rowCount; iRowNum++) {
                if (ExcelUtils.getCellData(iRowNum, colNum, sheetName).equalsIgnoreCase(sTestCaseName)) {
                    break;
                }
            }
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getRowContains | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return iRowNum;
    }

    public static int getTestStepsCount(String sheetName, String sTestCaseID, int iTestCaseStart) throws Exception {
        try {
            for (int i = iTestCaseStart; i <= ExcelUtils.getRowCountSteps(sheetName); i++) {
                if (!(sTestCaseID.equals(ExcelUtils.getCellData(i, Constants.Col_TestCaseID, sheetName)))) {
                    int number = i;
                    return number;
                }
            }
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            return ExcelWSheet.getLastRowNum() + 1;
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method getTestStepsCount | Exception desc : " + e);
            EngineGeneric.bResult = false;
            return 0;
        }
    }

    public static void setCellData(String result, int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            XSSFRow row = ExcelWSheet.getRow(rowNum);
            XSSFCell cell = row.getCell(colNum, org.apache.poi.ss.usermodel.Row.RETURN_BLANK_AS_NULL);

            if (cell == null) {
                CellStyle cellStyle = null;
                if (row.getCell(colNum) != null) {
                    cellStyle = row.getCell(colNum).getCellStyle();
                }
                cell = row.createCell(colNum);
                cell.setCellValue(result);
                if (row.getCell(colNum) != null) {
                    cell.setCellStyle(cellStyle);
                }
            } else {
                cell.setCellValue(result);
            }
            FileOutputStream fileOut = new FileOutputStream(EngineGeneric.sPathTestData);
            ExcelWBook.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setCellData | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    public static void clearCellResults(int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            int rownum = ExcelWSheet.getLastRowNum();
            for (int i = 1; i < rownum + 1; i++) {
                XSSFRow row = ExcelWSheet.getRow(i);
                if (row != null) {
                    XSSFCell cell = row.getCell(colNum);
                    if (cell != null) {
                        if (cell.getCTCell().isSetT())
                            cell.getCTCell().unsetT();
                        if (cell.getCTCell().isSetV())
                            cell.getCTCell().unsetV();
                    }
                }
            }
            FileOutputStream fileOut = new FileOutputStream(EngineGeneric.sPathTestData);
            ExcelWBook.write(fileOut);
            fileOut.flush();
            fileOut.close();
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method clearCellResults | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    public static void refreshFormulaCells() throws Exception {
        try {
            XSSFFormulaEvaluator.evaluateAllFormulaCells(ExcelWBook);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method refreshFormulaCells | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    public static void setCellToString(int rowNum, int colNum, String sheetName) throws Exception {
        try {
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            XSSFRow row = ExcelWSheet.getRow(rowNum);
            XSSFCell cell = row.getCell(colNum);
            cell.setCellType(Cell.CELL_TYPE_STRING);
        } catch (Exception e) {
            Log.error("Class ExcelUtils | Method setCellToString | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    public static int getCellsWithValue(XSSFSheet sheet, int total) {
        int newTotal = total;
        for (int i = 0; i < total; i++) {
            if (sheet.getRow(i).getCell(0).getCellType() == Cell.CELL_TYPE_BLANK){
                newTotal--;
            }
        }
        return newTotal;
    }
}
