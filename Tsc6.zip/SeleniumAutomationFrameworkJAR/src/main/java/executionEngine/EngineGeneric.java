package executionEngine;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.xml.DOMConfigurator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import config.ActionKeywords;
import config.Constants;
import utility.Common;
import utility.DateTimeFunctions;
import utility.ExcelUtils;
import utility.Log;

public class EngineGeneric {

    public static Properties OR;
    public static String sActionKeyword;
    public static String sPageObject;
    public static int iTestStep;
    public static int iTestLastStep;
    public static String sTestCaseID;
    public static String sOriginalTestCaseID;
    public static String sRunMode;
    public static String sData;
    public static String sPrint;
    public static boolean bResult;
    public static int columnOfParameter;
    public static String failStep;
    public static boolean failBrowser;
    public static String inicialTime;
    public static String finalTime;
    public static int cdTestCase;
    public static boolean corrupted;

    public static String sUrl;
    public static String sTimeLoadUrl;
    public static String sTimeDelayActions;
    public static String sRepeatError;
    public static String sCloseBrowserError;
    public static String sStopTestsError;
    public static String sKillProcesses;
    public static String sPathTestData;
    public static String sPathOR;
    public static String sPathDrivers;
    public static String sPathLog;
    public static String sUserB;
    public static String sPasswordB;

    /*
     * Descrição: Inicializa a execução do framework através da leitura do arquivo de configuração, definição dos arquivos de mapeamento (OR.txt)
     *          e de dados (DataEngine.xls), e definição dos arquivos de log (log4j.xml/log.txt) 
     */
    public static void initialize_Test() {
        try{
            corrupted = false;
            read_Config();

            String Path_OR = sPathOR;
            FileInputStream fs2 = new FileInputStream(Path_OR);
            OR = new Properties(System.getProperties());
            OR.load(new InputStreamReader(fs2, Charset.forName("UTF-8")));
            System.setProperty("logFilePath", sPathLog);
            DOMConfigurator.configure("log4j.xml");

            if((new File(sPathTestData).length()/1024) > 1){
                Common.copyFile(new File(sPathTestData), new File(sPathLog + "/Backup/DataEngine.xlsx"));
                Common.copyFile(new File(sPathOR), new File(sPathLog + "/Backup/OR.txt"));

                ExcelUtils.setExcelFile(sPathTestData);
            }
            else{
                corrupted = true;
                Log.fatal("A planilha 'DataEngine.xls' foi corrompida!");
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method initialize_Test | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Executa a automação 
     */
    public static void execute_TestCase(ActionKeywords actionKeywords, Method[] method2) {
        try{
            if(corrupted != true){
                cleanTestResults();

                // Obtém os cenários de teste e percorre pelas colunas para identificação dos passos (ações) que serão executados
                int iTotalTestCases = ExcelUtils.getRowCount(Constants.Sheet_TestCases);
                int controllerFail = 0;
                for (int iTestcase = 1; iTestcase < iTotalTestCases; iTestcase++) {
                    cdTestCase = iTestcase;
                    columnOfParameter = 0;
                    bResult = true;
                    sTestCaseID = ExcelUtils.getCellData(iTestcase, Constants.Col_TestCaseID, Constants.Sheet_TestCases);
                    sRunMode = ExcelUtils.getCellData(iTestcase, Constants.Col_RunMode, Constants.Sheet_TestCases);
                    sOriginalTestCaseID = sTestCaseID;
                    // Identifica através do nome do cenário de teste, qual será a coluna utilizada para leitura da massa de teste na aba de passos.
                    if (Character.isLetter(sTestCaseID.charAt(sTestCaseID.length() - 1))) {
                        sTestCaseID = sTestCaseID.substring(0, sTestCaseID.length() - 2);
                        columnOfParameter = getColumnDataTest(sOriginalTestCaseID);

                        // Caso o nome do cenário de teste esteja fora do padrão, o cenário será encerrado com falha e logada uma mensagem sobre a nomenclatura adequada
                        if (!sOriginalTestCaseID.substring(sOriginalTestCaseID.length() - 2, sOriginalTestCaseID.length() - 1).equals("_")) {
                            sRunMode = "No";
                            bResult = false;
                            Log.startTestCase(sOriginalTestCaseID);
                            Log.error("O ID do caso de teste está incorreto! O ID deve terminar com um número (TC_01002) ou com '_' mais uma letra indicando "
                                    + "a coluna com os dados de teste (TC_01002_K)");
                            Log.endTestCase(sTestCaseID);
                            ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,Constants.Sheet_TestCases);
                            ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail, Constants.Sheet_TestCases);
                            ExcelUtils.setCellData(DateTimeFunctions.getDifferenceBetweenTimes(inicialTime, finalTime), iTestcase, Constants.Col_Time,
                                Constants.Sheet_TestCases);
                        }
                    }
                    // Parametrização que identifica e filtra apenas os cenários de teste que serão executados
                    if (sRunMode.equals("Sim")) {
                        iTestStep = ExcelUtils.getRowContains(sTestCaseID, Constants.Col_TestCaseID, Constants.Sheet_TestSteps);
                        iTestLastStep = ExcelUtils.getTestStepsCount(Constants.Sheet_TestSteps, sTestCaseID, iTestStep);
                        Log.startTestCase(sOriginalTestCaseID);
                        bResult = true;
                        // Execução dos passos de teste do cenário corrente através da interpretação do método (keyword), objeto mapeado (elemento HTML),
                        // dado de teste (caso exista) e flag de print 
                        for (; iTestStep < iTestLastStep; iTestStep++) {
                            sActionKeyword = ExcelUtils.getCellData(iTestStep, Constants.Col_ActionKeyword,
                                Constants.Sheet_TestSteps).trim();
                            sPageObject = ExcelUtils.getPageObject(iTestStep, Constants.Col_PageObject,
                                Constants.Sheet_TestSteps);
                            sData = ExcelUtils.getCellData(iTestStep, Constants.Col_DataSet + columnOfParameter,
                                Constants.Sheet_TestSteps);
                            sPrint = ExcelUtils.getCellData(iTestStep, Constants.Col_Print, Constants.Sheet_TestSteps);

                            // O passo será executado apenas se os parâmetros forem obtidos sem erros
                            if (bResult == true){
                                execute_Actions(actionKeywords, method2);    
                            }

                            // Caso haja erro na execução de algum passo de teste o mesmo será definido com erro, o cenário será finalizado e os valores da execução
                            // registrados na planilha (resultado, tempo de execução, passo de teste com falha)
                            if (bResult == false) {
                                // Verifica se a execução do framework será encerrada caso haja erro em algum cenário
                                if (sStopTestsError.equals("S")) {
                                    ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                        Constants.Sheet_TestCases);
                                    ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                        Constants.Sheet_TestCases);
                                    iTestcase = iTotalTestCases;
                                } else {
                                    // Verifica se um cenário executado com erro será repetido por mais 2 vezes, ou seja, um cenário de teste tem até 3 execuções para ser
                                    // finalizado com sucesso, caso contrário o mesmo será definido com falha
                                    if (!sRepeatError.equals("S")) {
                                        ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                            Constants.Sheet_TestCases);
                                        ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                            Constants.Sheet_TestCases);
                                    } else {
                                        if (controllerFail < 3) {
                                            if (controllerFail == 2) {
                                                ExcelUtils.setCellData(Constants.KEYWORD_FAIL, iTestcase, Constants.Col_Result,
                                                    Constants.Sheet_TestCases);
                                                ExcelUtils.setCellData(failStep, iTestcase, Constants.Col_StepFail,
                                                    Constants.Sheet_TestCases);
                                                controllerFail = 0;
                                            } else {
                                                controllerFail++;
                                                iTestcase--;
                                            }
                                        }
                                    }
                                }
                                Log.endTestCase(sTestCaseID);
                                break;
                            }
                        }

                        // Caso haja êxito na execução de algum passo de teste o mesmo será definido com sucesso, o cenário será finalizado e os valores da execução
                        // registrados na planilha (resultado e tempo de execução)
                        if (bResult == true) {
                            controllerFail = 0;
                            Log.endTestCase(sTestCaseID);
                            ExcelUtils.setCellData(Constants.KEYWORD_PASS, iTestcase, Constants.Col_Result,Constants.Sheet_TestCases);
                            ExcelUtils.setCellData(DateTimeFunctions.getDifferenceBetweenTimes(inicialTime, finalTime), iTestcase, Constants.Col_Time,
                                Constants.Sheet_TestCases);
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method execute_TestCase | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Identifica a keyword parametrizada no passo da planilha e aciona o método correspondente a ser executado 
     */
    private static void execute_Actions(ActionKeywords actionKeywords, Method[] method2) {
        try{
            boolean existMethod = false; 
            for (int i = 0; i < method2.length; i++) {
                if (method2[i].getName().equalsIgnoreCase(sActionKeyword)) {
                    method2[i].invoke(actionKeywords, sPageObject, sData, sPrint);
                    existMethod = true;
                    if (bResult == true) {
                        break;
                    } 
                    // Caso seja especificado um browser diferente de IE, Chrome ou Firefox no cenário de teste, o mesmo será finalizado com falha
                    else if (failBrowser == true) {
                        failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                        bResult = false;
                        break;
                    } else {
                        failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                        // Verifica se o browser será encerrado caso haja alguma falha durante execução
                        if (sCloseBrowserError.equals("S")) {
                            ActionKeywords.closeBrowser("", "", "");
                        }
                        break;
                    }
                }
            }
            // Verifica se o browser será encerrado caso haja alguma falha durante execução
            if(existMethod == false){
                bResult = false;
                failStep = ExcelUtils.getCellData(iTestStep, Constants.Col_TestScenarioID, Constants.Sheet_TestSteps);
                Log.error("O método (keyword) informado '" + sActionKeyword + "' não existe.");
                if (sCloseBrowserError.equals("S")) {
                    ActionKeywords.closeBrowser("", "", "");
                }
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method execute_Actions | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Realiza a leitura do arquivo de configuração e associa aos parâmetros utilizados na execução 
     */
    public static void read_Config() {
        try{
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(Constants.PathApplication + "/config.xml");
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("parameters");

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    sUrl = eElement.getElementsByTagName("URL").item(0).getTextContent();
                    sTimeLoadUrl = eElement.getElementsByTagName("TempoCarregarURL").item(0).getTextContent();
                    sTimeDelayActions = eElement.getElementsByTagName("TempoEntrePassos").item(0).getTextContent();
                    sRepeatError = eElement.getElementsByTagName("RepeteCTErro").item(0).getTextContent();
                    sCloseBrowserError = eElement.getElementsByTagName("FechaBrowserErro").item(0).getTextContent();
                    sStopTestsError = eElement.getElementsByTagName("FinalizaTesteErro").item(0).getTextContent();
                    sKillProcesses = eElement.getElementsByTagName("FinalizaProcessoBrowser").item(0).getTextContent();
                    sPathTestData = Common.convertPathWindowsFormat(
                        eElement.getElementsByTagName("DiretorioXls").item(0).getTextContent()) + "/DataEngine.xlsx";
                    sPathOR = Common.convertPathWindowsFormat(
                        eElement.getElementsByTagName("DiretorioOR").item(0).getTextContent()) + "/OR.txt";
                    sPathDrivers = Common.convertPathWindowsFormat(
                        eElement.getElementsByTagName("DiretorioDrivers").item(0).getTextContent()) + "/";
                    sPathLog = Common.convertPathWindowsFormat(eElement.getElementsByTagName("DiretorioLog").item(0).getTextContent());
                    sUserB = eElement.getElementsByTagName("Usuario").item(0).getTextContent();
                    sPasswordB = eElement.getElementsByTagName("Senha").item(0).getTextContent();
                }
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method read_Config | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Finaliza os drivers e/ou browsers que estiverem presos após uma execução 
     */
    public static void end_Drivers() {
        try{
            if(sKillProcesses.equals("S")){
                if (Constants.TypeBrowser == 1) {
                    if (Common.getProcessesRunning().contains("geckodriver")) {
                        Runtime.getRuntime().exec("taskkill /F /IM geckodriver.exe");
                    }
                    if (Common.getProcessesRunning().contains("firefox")) {
                        Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
                    }
                } else if (Constants.TypeBrowser == 2) {
                    if (Common.getProcessesRunning().contains("IEDriverServer")) {
                        Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
                    }
                    if (Common.getProcessesRunning().contains("iexplore")) {
                        Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
                    }
                } else if (Constants.TypeBrowser == 3) {
                    if (Common.getProcessesRunning().contains("chromedriver")) {
                        Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
                    }
                    if (Common.getProcessesRunning().contains("chrome")) {
                        Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
                    }
                }   
            }  
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method end_Drivers | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Identifica o objeto (elemento HTML) do próximo passo, para que a ação atual seja executada e aguarde até que este objeto esteja disponível
     * para interação, em seguida o passo é finalizado a execução prossegue com o passo seguinte 
     */
    public static void waitNextObject(){
        try {
            String sPageObject = ExcelUtils.getPageObject(iTestStep+1, Constants.Col_PageObject, Constants.Sheet_TestSteps);
            String sKeyWord = ExcelUtils.getCellData(iTestStep+1, Constants.Col_ActionKeyword, Constants.Sheet_TestSteps).trim();
            // Verifica se no próximo passo a ação a ser executada é "navigate", "switchToComponent" ou "switchToFrame". Em caso afirmativo, o objeto (elemento HTML)
            // do passo seguinte é ignorado
            if(!(sKeyWord.equalsIgnoreCase("navigate") || sKeyWord.equalsIgnoreCase("switchToComponent") || sKeyWord.equalsIgnoreCase("switchToFrame"))){
                if(!sPageObject.isEmpty()){
                    if(OR.getProperty(sPageObject).substring(0, 1).equals("/")){
                        ActionKeywords.waitUntil(sPageObject, "", "");
                    }
                }
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method waitNextObject | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Limpa as colunas com o resultado da execução, tempo da execução e passo que falhou
     */
    public static void cleanTestResults() {
        try {
            ExcelUtils.clearCellResults(Constants.Col_Time, Constants.Sheet_TestCases);
            ExcelUtils.clearCellResults(Constants.Col_Result, Constants.Sheet_TestCases);
            ExcelUtils.clearCellResults(Constants.Col_StepFail, Constants.Sheet_TestCases);
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method cleanTestResults | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
    }

    /*
     * Descrição: Obtém a coluna utilizada para leitura da massa de teste na aba de passos, através do nome do cenário de teste. 
     * Caso o nome do cenário seja terminado com H ou por número, a massa de teste será obtida na coluna H da aba de passos. Caso 
     * seja terminado com I a massa de teste será obtida na coluna I da aba de passos, e assim por diante.
     */
    public static int getColumnDataTest(String sTestCasePrefix) {
        int columnOfParameter = 0;
        try {
            switch (sTestCasePrefix.substring(sTestCasePrefix.length() - 1).toUpperCase()) {
                case "I":
                    columnOfParameter = 1;
                    break;
                case "J":
                    columnOfParameter = 2;
                    break;
                case "K":
                    columnOfParameter = 3;
                    break;
                case "L":
                    columnOfParameter = 4;
                    break;
                case "M":
                    columnOfParameter = 5;
                    break;
                case "N":
                    columnOfParameter = 6;
                    break;
                case "O":
                    columnOfParameter = 7;
                    break;
                case "P":
                    columnOfParameter = 8;
                    break;
                case "Q":
                    columnOfParameter = 9;
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            Log.error("Class EngineGeneric | Method getColumnDataTest | Exception desc : " + e);
            EngineGeneric.bResult = false;
        }
        return columnOfParameter;
    }
}
