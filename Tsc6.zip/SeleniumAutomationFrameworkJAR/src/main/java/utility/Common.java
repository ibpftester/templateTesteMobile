package utility;

import static executionEngine.EngineGeneric.OR;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import executionEngine.EngineGeneric;

public class Common {

    private Common(){}
    
    /*
     * Descrição: Retorna o elemento web correspondente a um atributo de uma tabela (grid)
     * Parâmetros:
     *          valueField: registro do arquivo OR.txt correspondente ao xpath da coluna do grid a ser analisada (coluna)
     *          index: índice correspondente à linha do registro a ser obtido no grid (linha)
     *          driver: driver em execução
     */
    public static WebElement getXPathRowGrid(String valueField, int index, WebDriver driver) {
        WebElement element = null;
        try{
            String xpathColumnGrid = OR.getProperty(valueField);
            String newXPathStart = xpathColumnGrid.substring(0, xpathColumnGrid.lastIndexOf("]/td[") - 1);
            String newXPathEnd = xpathColumnGrid.substring(xpathColumnGrid.lastIndexOf("table/tbody/tr[1") + 16,
                xpathColumnGrid.length());
            String newXPathColunaGrid = newXPathStart + ++index + newXPathEnd;
            element = driver.findElement(By.xpath(newXPathColunaGrid));            
        } catch (Exception e){
            Log.error("Class Common | Method getXPathRowGrid | Exception desc : " + e);
        }
        return element;
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente
     * Parâmetros:
     *          milliseconds: tempo em milisegundos que a aplicação ficará suspensa
     */
    public static void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Log.error("Class Common | Method wait | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente de acordo com valor parametrizado no config
     */
    public static void waitStandard() {
        try {
            wait(Integer.parseInt(EngineGeneric.sTimeDelayActions) * 1000);
        } catch (Exception e) {
            Log.error("Class Common | Method waitStandard | Exception desc : " + e);
        }
    }
    
    /*
     * Descrição: Verifica se existe um arquivo em um diretório
     * Parâmetros:
     *          downloadPath: diretório que será verificado
     *          fileName: nome do arquivo que será verificado
     */
    public static boolean isFileDownloaded(String downloadPath, String fileName) {
        boolean flag = false;
        try {
            File dir = new File(downloadPath);
            File[] dirContents = dir.listFiles();
            for (int i = 0; i < dirContents.length; i++) {
                if (dirContents[i].getName().contains(fileName)) {
                    flag = true;
                    return flag;
                }
            }
        } catch (Exception e) {
            Log.error("Class Common | Method isFileDownloaded | Exception desc : " + e);
        }
        return flag;
    }

    /*
     * Descrição: Verifica se existe um arquivo em um diretório, em caso afirmativo o mesmo será excluído
     * Parâmetros:
     *          downloadPath: diretório que será verificado
     *          fileName: nome do arquivo que será verificado/excluído
     */
    public static boolean isFileDeleted(String downloadPath, String fileName) {
        try{
            File file = new File(downloadPath + "\\" + fileName);
            if (file.exists()) {
                file.delete();
            }
            wait(3000);  
        } catch (Exception e) {
            Log.error("Class Common | Method isFileDeleted | Exception desc : " + e);
        }
        return !isFileDownloaded(downloadPath, fileName);
    }

    /*
     * Descrição: Retorna o xpath de um elemento web
     * Parâmetros:
     *          driver: driver em execução
     *          element: elemento web para obtenção do xpath
     */
    public static String getElementXPath(WebDriver driver, WebElement element) {
        String elementXpath = "";
        try{
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            String xpathOriginal = (String) executor.executeScript(
                "gPt=function(c){if(c.id!==''){return'//*[@id=\"'+c.id+'\"]'}if(c===document.body){return c.tagName}var a=0;var e=c.parentNode.childNodes;"
                + "for(var b=0;b<e.length;b++){var d=e[b];if(d===c){return gPt(c.parentNode)+'/'+c.tagName+'['+(a+1)+']'}if(d.nodeType===1&&d.tagName===c.tagName)"
                + "{a++}}};return gPt(arguments[0]);",
                element);
            elementXpath = xpathOriginal.replace("\"", "'").replace("[1]", "");
        } catch (Exception e) {
            Log.error("Class Common | Method getElementXPath | Exception desc : " + e);
        }
        return elementXpath;
    }

    /*
     * Descrição: Recebe um diretório no formato Windows e retorna uma string com o diretório no formato de execução
     * Parâmetros:
     *          path: diretório no formato Windows
     */
    public static String convertPathWindowsFormat(String path) {
        String newPath = "";
        try{
            newPath = path.replace("C:\\", "C://").replace("\\", "/");
        } catch (Exception e) {
            Log.error("Class Common | Method convertPathWindowsFormat | Exception desc : " + e);
        }
        return newPath;
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente até que um elemento HTML seja exibido na tela
     * Parâmetros:
     *          webElement: elemento web aguardado a ser exibido na página
     *          driver: driver em execução
     */
    public static void waitUntilElementDisplayed(WebElement webElement, WebDriver driver) {
        try{
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            WebDriverWait wait = new WebDriverWait(driver, 90);
            ExpectedCondition<Boolean> elementIsDisplayed = new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver arg0) {
                  try {
                      webElement.isDisplayed();
                      return true;
                  }
                  catch (NoSuchElementException | StaleElementReferenceException e) {
                      Log.error("Class Common | Method waitUntilElementDisplayed | Exception desc : " + e);
                      return false;
                  }
                }
            };
            wait.until(elementIsDisplayed);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        } catch (Exception e) {
            Log.error("Class Common | Method waitUntilElementDisplayed | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Obtém e retorna uma lista com os processos em execução no sistema operacional
     * Parâmetros:
     *          path: diretório no formato Windows
     */
    public static String getProcessesRunning() {
        String pidInfo = "";
        try {
            String line;
            Process p = Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
            BufferedReader input =  new BufferedReader(new InputStreamReader(p.getInputStream()));
            while ((line = input.readLine()) != null) {
                pidInfo+=line;
            }
            input.close();
        } catch (IOException e) {
            Log.error("Class Common | Method getProcessesRunning | Exception desc : " + e);
        }
        return pidInfo;
    }

    /*
     * Descrição: Copia um arquivo (backup) para um determinado diretório. Caso já exista um arquivo no diretório de destino, 
     *          o mesmo é deletado e substituído pelo novo arquivo copiado.
     * Parâmetros:
     *          source: diretório do arquivo a ser copiado
     *          dest: diretório onde o arquivo copiado será disponibilizado
     */
    public static void copyFile(File source, File dest) {
        try {
            String file = dest.getAbsolutePath().substring(dest.getAbsolutePath().lastIndexOf("\\")+1);
            String path = dest.getAbsolutePath().substring(0, dest.getAbsolutePath().lastIndexOf("\\"));

            if (!new File(path).exists()) {
                new File(path).mkdir();
            }

            FileInputStream sourceChannel = new FileInputStream(source);
            FileOutputStream destChannel = new FileOutputStream(dest);
            isFileDeleted(path, file);
            destChannel.getChannel().transferFrom(sourceChannel.getChannel(), 0, sourceChannel.getChannel().size());
            sourceChannel.close();
            destChannel.close();
        } catch (Exception e) {
            Log.error("Class Common | Method copyFile | Exception desc : " + e);
        }
    }
}
