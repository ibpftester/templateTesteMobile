package utility;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import config.Constants;
import executionEngine.EngineGeneric;

public class ScreenCapture {

    static String namePath = Constants.NamePath;
    static String idPath = (DateTimeFunctions.getCurrentDate() + "_" + DateTimeFunctions.getCurrentTime())
        .substring(0, 19);

    /*
     * Descrição: Registra um print da tela e armazena em um diretório
     * Parâmetros: 
     *          flag: valor booleano que define se o print será registrado (Sim / Não)
     */
    public static void takePrintScreen(String flag) {
        if(flag.equals("Sim")){
            try {
                String nameSubPath = Constants.NamePath + "\\" + idPath + "\\" + EngineGeneric.sOriginalTestCaseID;

                createPaths();

                createSubPath(nameSubPath);

                ImageIO.write(generateImage(), "jpg", new File(Constants.PathScreenshots + "\\" + nameSubPath + "\\"
                    + DateTimeFunctions.getCurrentTime() + ".jpg"));
            } catch (IOException e) {
                Log.error("Class ScreenCapture | Method takePrintScreen | Exception desc : " + e);
            }            
        }
    }

    /*
     * Descrição: Registra um print da tela em caso de erro e armazena em um diretório
     */
    public static void takeErrorPrintScreen() {
        try {
            String nameSubPath = Constants.NamePath + "\\" + idPath + "\\Erros\\" + EngineGeneric.sOriginalTestCaseID;

            createPaths();

            if (!new File(Constants.PathScreenshots + "\\" + namePath + "\\" + idPath + "\\Erros").exists()) {
                new File(Constants.PathScreenshots + "\\" + namePath + "\\" + idPath + "\\Erros").mkdir();
            }

            createSubPath(nameSubPath);

            ImageIO.write(generateImage(), "jpg", new File(Constants.PathScreenshots + "\\" + nameSubPath + "\\"
                + "Error_" + DateTimeFunctions.getCurrentTime() + ".jpg"));
        } catch (IOException e) {
            Log.error("Class ScreenCapture | Method takeErrorPrintScreen | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Cria um diretório caso o mesmo não exista
     */
    public static void createPaths() {
        if (!new File(Constants.PathScreenshots).exists()) {
            new File(Constants.PathScreenshots).mkdir();
        }

        if (!new File(Constants.PathScreenshots + "\\" + namePath).exists()) {
            new File(Constants.PathScreenshots + "\\" + namePath).mkdir();
        }

        if (!new File(Constants.PathScreenshots + "\\" + namePath + "\\" + idPath).exists()) {
            new File(Constants.PathScreenshots + "\\" + namePath + "\\" + idPath).mkdir();
        }
    }

    /*
     * Descrição: Cria uma subpasta dentro de um determinado diretório caso a mesma não exista
     * Parâmetros: 
     *          nameSubPath: nome da subpasta a ser criada
     */
    public static void createSubPath(String nameSubPath) {
        if (!new File(Constants.PathScreenshots + "\\" + nameSubPath).exists()) {
            new File(Constants.PathScreenshots + "\\" + nameSubPath).mkdir();
        }
    }

    /*
     * Descrição: Gera a imagem do print da tela
     */
    public static BufferedImage generateImage() {
        BufferedImage screencapture = null;
        try {
            screencapture = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        } catch (HeadlessException | AWTException e) {
            Log.error("Class ScreenCapture | Method generateImage | Exception desc : " + e);
        }
        return screencapture;
    }
}
