package utility;

import org.apache.log4j.Logger;

import config.Constants;
import executionEngine.EngineGeneric;

public class Log {

    private static Logger Log = Logger.getLogger(Log.class.getName());

    /*
     * Descrição: Registra log de início da execução do caso de teste e define hora de início
     * Parâmetros: 
     *          sTestCaseName: nome do caso de teste em execução
     */
    public static void startTestCase(String sTestCaseName) {
        Log.info("****************************************************************************************");
        Log.info("****************************************************************************************");
        Log.info("$$$$$$$$$$$$$$$$$$$$$                 " + sTestCaseName + "       $$$$$$$$$$$$$$$$$$$$$$$$$");
        Log.info("****************************************************************************************");
        Log.info("****************************************************************************************");
        EngineGeneric.inicialTime = DateTimeFunctions.getCurrentTime();
    }

    /*
     * Descrição: Registra log e hora de encerramento da execução do caso de teste
     * Parâmetros: 
     *          sTestCaseName: nome do caso de teste em execução
     */
    public static void endTestCase(String sTestCaseName) {
        Log.info("XXXXXXXXXXXXXXXXXXXXXXX             " + "-E---N---D-" + "             XXXXXXXXXXXXXXXXXXXXXX");
        Log.info("X");
        Log.info("X");
        Log.info("X");
        Log.info("X");
        try {
            EngineGeneric.finalTime = DateTimeFunctions.getCurrentTime();
            ExcelUtils.setCellData(DateTimeFunctions.getDifferenceBetweenTimes(EngineGeneric.inicialTime, EngineGeneric.finalTime), EngineGeneric.cdTestCase, Constants.Col_Time,
                Constants.Sheet_TestCases);
        } catch (Exception e) {
            Log.error("Class Log | Method endTestCase | Exception desc : " + e);
        }
    }

    /*
     * Descrição: Registra log informativo
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void info(String message) {
        Log.info(message);
    }

    /*
     * Descrição: Registra log de aviso
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void warn(String message) {
        Log.warn(message);
    }

    /*
     * Descrição: Registra log de erros
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void error(String message) {
        Log.error(message);
    }

    /*
     * Descrição: Registra log de falha explícita ou situação não recuperável
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void fatal(String message) {
        Log.fatal(message);
    }

    /*
     * Descrição: Registra log de debug
     * Parâmetros: 
     *          message: informação a ser registrada no log
     */
    public static void debug(String message) {
        Log.debug(message);
    }
}
