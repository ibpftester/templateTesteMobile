package utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeFunctions {

    /*
     * Descrição: Obtém a hora atual no formato "HH.mm.ss.SSS"
     */
    public static String getCurrentTime() {
        String time = "";
        try{
            time = new SimpleDateFormat("HH.mm.ss.SSS").format(new Date().getTime()); 
        } catch (Exception e) {
            Log.error("Class DateTimeFunctions | Method getTimeScreenShot | Exception desc : " + e);
        }
        return time;
    }

    /*
     * Descrição: Obtém a data atual no formato "yyyy.MM.dd"
     */
    public static String getCurrentDate() {
        String date = "";
        try{
            date = new SimpleDateFormat("yyyy.MM.dd").format(new Date().getTime()); 
        } catch (Exception e) {
            Log.error("Class DateTimeFunctions | Method getCurrentDate | Exception desc : " + e);
        }
        return date;
    }

    /*
     * Descrição: Obtém a data atual no formato "dd/MM/yyyy"
     */
    public static String getCurrentDateBrFormat() {
        String date = "";
        try{
            date = new SimpleDateFormat("dd/MM/yyyy").format(new Date().getTime()); 
        } catch (Exception e) {
            Log.error("Class DateTimeFunctions | Method getCurrentDateBrFormat | Exception desc : " + e);
        }
        return date;
    }

    /*
     * Descrição: Obtém uma data através de uma string no formato "dd/MM/yyyy"
     * Parâmetros:
     *          date: texto no formato de data
     */
    public static Date convertStringToDate(String date) {
        Date newDate = null;
        try {
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            newDate = formatter.parse(date);
        } catch (ParseException e) {
            Log.error("Class DateTimeFunctions | Method convertStringToDate | Exception desc : " + e);
        }
        return newDate;
    }

    /*
     * Descrição: Obtém a diferença entre um intervalo de tempo no formato "HH.mm.ss"
     * Parâmetros:
     *          inicialTime: hora inicial
     *          finalTime: hora final
     */
    public static String getDifferenceBetweenTimes(String inicialTime, String finalTime) {
        String time = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat("HH.mm.ss");
            long diff = format.parse(finalTime).getTime() - format.parse(inicialTime).getTime();
            String diffSeconds = String.format("%02d", diff / 1000 % 60);
            String diffMinutes = String.format("%02d", diff / (60 * 1000) % 60);
            String diffHours = String.format("%02d", diff / (60 * 60 * 1000) % 24);
            time = diffHours + ":" + diffMinutes + ":" + diffSeconds;
        } catch (ParseException e) {
            Log.error("Class DateTimeFunctions | Method getDifferenceBetweenTimes | Exception desc : " + e);
        }
        return time;
    }
}
