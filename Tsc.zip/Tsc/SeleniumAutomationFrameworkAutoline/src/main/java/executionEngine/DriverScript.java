package executionEngine;

import java.lang.reflect.Method;

import config.ActionKeywords;
import project.ActionKeywordsSpecific;

public class DriverScript {

    public static ActionKeywordsSpecific actionKeywordsSpecifc;
    public static Method method[];

    public DriverScript() throws NoSuchMethodException, SecurityException {
        actionKeywordsSpecifc = new ActionKeywordsSpecific();
        method = actionKeywordsSpecifc.getClass().getMethods();
    }

    public static void main(String[] args) throws Exception {
        EngineGeneric.initialize_Test();

        DriverScript startEngine = new DriverScript();
        startEngine.genericTest(actionKeywordsSpecifc, method);

        EngineGeneric.end_Drivers();
    }

    private void genericTest(ActionKeywords actionKeywords, Method[] method2) throws Exception {
        EngineGeneric.execute_TestCase(actionKeywords, method2);
    }
}
