package utility;

import static executionEngine.EngineGeneric.OR;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import executionEngine.EngineGeneric;

public class Common {

    private Common(){}
    
    /*
     * Descrição: Retorna o elemento web correspondente a um atributo de uma tabela (grid)
     * Parâmetros:
     *          valueField: registro do arquivo OR.txt correspondente ao xpath da coluna do grid a ser analisada (coluna)
     *          index: índice correspondente à linha do registro a ser obtido no grid (linha)
     *          driver: driver em execução
     */
    public static WebElement getXPathRowGrid(String valueField, int index, WebDriver driver) {
        String xpathColumnGrid = OR.getProperty(valueField);
        String newXPathStart = xpathColumnGrid.substring(0, xpathColumnGrid.lastIndexOf("]/td[") - 1);
        String newXPathEnd = xpathColumnGrid.substring(xpathColumnGrid.lastIndexOf("table/tbody/tr[1") + 16,
            xpathColumnGrid.length());
        String newXPathColunaGrid = newXPathStart + ++index + newXPathEnd;
        return driver.findElement(By.xpath(newXPathColunaGrid));
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente
     * Parâmetros:
     *          milliseconds: tempo em milisegundos que a aplicação ficará suspensa
     */
    public static void wait(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Log.error("Falha ao executar o método de espera --- " + e);
        }
    }

    /*
     * Descrição: Suspende a execução da aplicação temporariamente de acordo com valor parametrizado no config
     */
    public static void waitStandard() {
        wait(Integer.parseInt(EngineGeneric.sTimeDelayActions) * 1000);
    }
    
    /*
     * Descrição: Verifica se existe um arquivo em um diretório
     * Parâmetros:
     *          downloadPath: diretório que será verificado
     *          fileName: nome do arquivo que será verificado
     */
    public static boolean isFileDownloaded(String downloadPath, String fileName) {
        boolean flag = false;
        File dir = new File(downloadPath);
        File[] dirContents = dir.listFiles();
        for (int i = 0; i < dirContents.length; i++) {
            if (dirContents[i].getName().contains(fileName)) {
                flag = true;
                return flag;
            }
        }
        return flag;
    }

    /*
     * Descrição: Verifica se existe um arquivo em um diretório, em caso afirmativo o mesmo será excluído
     * Parâmetros:
     *          downloadPath: diretório que será verificado
     *          fileName: nome do arquivo que será verificado/excluído
     */
    public static boolean isFileDeleted(String downloadPath, String fileName) {
        File file = new File(downloadPath + "\\" + fileName);
        if (file.exists()) {
            file.delete();
        }
        wait(3000);
        return !isFileDownloaded(downloadPath, fileName);
    }

    /*
     * Descrição: Retorna o xpath de um elemento web
     * Parâmetros:
     *          driver: driver em execução
     *          element: elemento web para obtenção do xpath
     */
    public static String getElementXPath(WebDriver driver, WebElement element) {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        String xpathOriginal = (String) executor.executeScript(
            "gPt=function(c){if(c.id!==''){return'//*[@id=\"'+c.id+'\"]'}if(c===document.body){return c.tagName}var a=0;var e=c.parentNode.childNodes;"
            + "for(var b=0;b<e.length;b++){var d=e[b];if(d===c){return gPt(c.parentNode)+'/'+c.tagName+'['+(a+1)+']'}if(d.nodeType===1&&d.tagName===c.tagName)"
            + "{a++}}};return gPt(arguments[0]);",
            element);
        return xpathOriginal.replace("\"", "'").replace("[1]", "");
    }

    /*
     * Descrição: Recebe um diretório no formato Windows e retorna uma string com o diretório no formato de execução
     * Parâmetros:
     *          path: diretório no formato Windows
     */
    public static String convertPathWindowsFormat(String path) {
        return path.replace("C:\\", "C://").replace("\\", "/");
    }
}
