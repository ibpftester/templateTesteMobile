package project;

import static executionEngine.EngineGeneric.OR;
import static org.testng.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import config.ActionKeywords;
import config.Constants;
import executionEngine.EngineGeneric;
import utility.Common;
import utility.ExcelUtils;
import utility.Log;
import utility.ScreenCapture;

public class ActionKeywordsSpecific extends ActionKeywords {

    public static void getValueOfAttribute(String object, String data, String print) {
        try {
            List<String> valoresCampos = Arrays.asList(OR.getProperty(object).split("\\s*;\\s*"));
            String valueString = driver.findElement(By.xpath(OR.getProperty(valoresCampos.get(0)))).getAttribute(valoresCampos.get(1));

            ExcelUtils.setCellData(valueString, EngineGeneric.iTestStep, Constants.Col_DataSet,
                Constants.Sheet_TestSteps);
            ExcelUtils.refreshFormulaCells();
            Log.info("Obtém o valor do atributo '" + valoresCampos.get(1) + "' do elemento '" + object + "'");
            Common.waitStandard();
            ScreenCapture.takePrintScreen(print);
        } catch (Exception e) {
            Log.error("Não foi possível obter o valor do atributo '" + object + "' --- " + e);
            EngineGeneric.bResult = false;
            ScreenCapture.takeErrorPrintScreen();
        }
    }

    public static void validateFieldsClear(String object, String data, String print) {
        try {
            List<String> valoresCampos = Arrays.asList(OR.getProperty(object).split("\\s*;\\s*"));

            for (int i = 0; i < valoresCampos.size(); i++) {
                WebElement elementWebField = driver.findElement(By.xpath(OR.getProperty(valoresCampos.get(i))));
                String elementTypeField = elementWebField.getTagName();

                if (elementTypeField.contains("input") || elementTypeField.contains("textarea")) {
                    if(elementWebField.getAttribute("type").equals("checkbox")){
                        if (elementWebField.getAttribute("value").equals("sim")) {
                            assertTrue(elementWebField.isSelected());
                        } else {
                            assertTrue(!elementWebField.isSelected());
                        }
                    }
                    else{
                        assertTrue(elementWebField.getAttribute("value").isEmpty());    
                    }
                }

                else if (elementTypeField.contains("button")) {
                    assertTrue(elementWebField.getAttribute("class").contains("bs-placeholder btn-default"));
                }
            }
            ScreenCapture.takePrintScreen(print);
            Log.info("Valida se a funcionalidade de limpar campos está funcionando");
        } catch (Exception | AssertionError e) {
            Log.error("Não foi possível validar se a funcionalidade de limpar campos está funcionando --- " + e);
            EngineGeneric.bResult = false;
            ScreenCapture.takeErrorPrintScreen();
        }
    }
}
