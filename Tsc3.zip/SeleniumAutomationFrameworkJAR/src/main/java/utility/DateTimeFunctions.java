package utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeFunctions {

    public static String getTimeScreenShot() {
        return new SimpleDateFormat("HH.mm.ss.SSS").format(new Date().getTime());
    }

    public static String getCurrentDate() {
        return new SimpleDateFormat("yyyy.MM.dd").format(new Date().getTime());
    }

    public static String getCurrentDateBrFormat() {
        return new SimpleDateFormat("dd/MM/yyyy").format(new Date().getTime());
    }

    public static Date convertStringToDate(String date) {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date newDate = null;
        try {
            newDate = formatter.parse(date);
        } catch (ParseException e) {
            Log.error("Falha ao converter string para data --- " + e);
        }
        return newDate;
    }
}
