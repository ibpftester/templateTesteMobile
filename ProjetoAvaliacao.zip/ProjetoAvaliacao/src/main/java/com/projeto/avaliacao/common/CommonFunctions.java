package com.projeto.avaliacao.common;

public class CommonFunctions {

    public static void waitTime(long milliseconds){
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
