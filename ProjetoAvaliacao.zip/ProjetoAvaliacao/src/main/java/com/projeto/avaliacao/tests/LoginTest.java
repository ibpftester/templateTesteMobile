package com.projeto.avaliacao.tests;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.projeto.avaliacao.page.objects.LoginPage;
import com.projeto.avaliacao.page.objects.MenuPage;

public class LoginTest {

    private WebDriver driver;

    @Before
    public void before() {
        System.setProperty("webdriver.chrome.driver", "../ProjetoAvaliacao/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void loginComSucesso() {
        LoginPage loginPage = new LoginPage(driver);
        MenuPage homePage = loginPage.visita("http://172.16.42.153:8080/push-services-web/").autentica("operador@scopus.com.br", "Scopus");

        assertTrue(homePage.isValida());
    }

    @After
    public void after() {
        driver.quit();
    }

}
