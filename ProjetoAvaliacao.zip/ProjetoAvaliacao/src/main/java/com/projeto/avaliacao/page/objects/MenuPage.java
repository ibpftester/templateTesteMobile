package com.projeto.avaliacao.page.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MenuPage {

    private WebDriver driver;

    public MenuPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isValida() {
        return temBarraNavegacao() && temListagemProjetos();
    }

    private boolean temBarraNavegacao() {
        return driver.findElement(By.xpath("//*[@class='md-icon-button md-button md-ink-ripple']")) != null;
    }

    private boolean temListagemProjetos() {
        return driver.findElement(By.xpath("//*[@class='hide-xs ng-binding']")).getText().contains("Scopus Push Services");
    }

}
