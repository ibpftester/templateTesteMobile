package com.projeto.avaliacao.page.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.projeto.avaliacao.common.CommonFunctions;

public class LoginPage {

    private WebDriver driver;
    
    public LoginPage(WebDriver driver) {
      this.driver = driver;
    }
    
    public LoginPage visita(String url) {
      driver.get(url);
      CommonFunctions.waitTime(8000);
      return this;
    }
    
    public MenuPage autentica(String usuario, String senha) {
      driver.findElement(By.id("username")).sendKeys(usuario);
      driver.findElement(By.id("password")).sendKeys(senha);
      driver.findElement(By.cssSelector("button[type='submit'")).click();

      CommonFunctions.waitTime(6000);
     
      return new MenuPage(driver);
    }
    
}
